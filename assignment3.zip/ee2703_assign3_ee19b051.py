""" 
Roll no: ee19b051
assignment3: fiiting datas to models
"""


import numpy as np # here i am importing numpy module for mathemetical calculation
import pylab as pl # for plotting the graphs we need pylab module,also for least square
import scipy.special as sp # importing scipy module for special functions like bessels function

pmtr = np.array([1.05,-0.105]) # here i am making an array named pmtr  of actual values of the parameters to be found
def g(t,A,B): # defining the model including parameters to be found
    return(A*sp.jn(2,t) + B*t)

#Function to estimate and return the parameters A and B
def estimate_A_B(M,col): # here we are finding A,B by using least square method in pylab
    AB = pl.lstsq(M,col,rcond=None) # note: here the output will be an array/matrix  containing the two parameters
    return(AB[0][0],AB[0][1])
    

data = np.loadtxt("fitting.dat") # Extracting data from "fitting.dat" into array "data"
t = data[:,0] # here 0 is because first column is th time column in the data matrix

y0 = g(t,pmtr[0],pmtr[1]) # actual output values calculated using true parameters
stdev = np.logspace(-1, -3, 9)                          #Std dev for errors in data columns in order


"""
Plot 1: It contains - Plot of true value
                    - Plot of 9 sets of noisy data
"""
pl.figure(0) # 1st plot
for i in range(1,10):
    pl.plot(t,data[:,i],label="\u03C3 = %0.4f" % stdev[i-1]) # here measured values of functions are plotted against t including error
pl.plot(t,y0,label="True plot",color='black',linewidth = 2) # plotting actual model with black color
pl.title("Q3. True plot along with nine other noisy plots") # giving title to the plot
pl.xlabel("$t$",size = 10) # giving the axes names
pl.ylabel("$f(t) + n$",size = 10) 
pl.grid(True) # grid:allowed
pl.legend()

"""
Plot 2: It contains - Data points of firt column with errorbars
                    - Plot of true value
"""
pl.figure(1) #2nd plot
pl.errorbar(t[::5],data[:,1][::5],stdev[1],fmt='ro',label="error bar") # plotting error for one column
pl.plot(t,y0,label = "True value",color = 'black',linewidth=2)# actual plot
pl.xlabel("$t$")
pl.title("Q5. Plot of First column of data with error bars and the True value")
pl.grid(True)
pl.legend()

Jt = sp.jn(2,t) # now making matrix required in Q6
M = pl.c_[Jt,t]
if (np.array_equal(np.dot(M,pmtr),y0)): #Verifying whether M.pmtr is equal to the actual model
    print("M*[A0,B0] is equal to g(t,A0,B0). Verified")
else:
    print("M*[A0;B0] is NOT equal to g(t,A0,B0).")

"""
Mean Squared Error for column 1 and assummed model for - A ranging from 0 to 2 in steps of 0.1
                                                       - B ranging from -0.2 to 0 in steps of 0.01
"""
A = np.linspace(0, 2, 21) #A from 0 to 2 in counts of 0.1
B = np.linspace(-0.2, 0, 21) #B from -0.2 to 0 in counts of 0.01
a,b = np.meshgrid(A,B) #meshgrid for plotting contour
Err = np.zeros((21,21)) #Matrix to store to store Mean Squared Errors for different combinations of A and B
f1 = data[:,1] #First column of data
for i in range(21):
    for j in range(21):
        Err[i,j] += np.sum(((f1 - g(t,A[i],B[j]))**2))/101

"""
Plot 3: Contour PLOT
"""
fig=pl.figure(2)
cp = pl.contour(a,b,Err,[0.025,0.05,0.075,0.1,0.125,0.15,0.175,0.2,0.225,0.25,0.275,0.3])
#pl.contour(1.05,-0.105,0)
pl.clabel(cp,[0.025,0.05,0.075,0.1],inline=1)                #Labeling in line
fig.colorbar(cp) #Adding a color bar to the plot to indicate the level of contours
pl.title("Q8. Contour plot for errors $\epsilon_{ij}$")
pl.xlabel("$A$")
pl.ylabel("$B$")
pl.show()


Aerr,Berr = np.zeros(9),np.zeros(9) #Arrays to store the MS error in the prediction of A and B for different amount of noise
for i in range(1,10):
    A_est,B_est = estimate_A_B(M,data[:,i]) #the function "estimate_A_B()" estimates by the method of least squares
    Aerr[i-1] += ((A_est - pmtr[0])**2)
    Berr[i-1] += (B_est - pmtr[1])**2
 
"""
Plot 4
"""
pl.figure(3)
pl.plot(stdev,Aerr,marker = "*",label="$A_{err}$",linestyle = 'dashed')
pl.plot(stdev,Berr,marker = "*",label="$B_{err}$",linestyle = 'dashed')
pl.grid(True)
pl.xlabel("\u03C3",size=11)
pl.ylabel("$MSerror$")
pl.title("Q10. changes in Error with Noise(linear scale)")
pl.legend()
pl.show()
    

"""
Plot 4
"""
pl.figure(4)
pl.loglog(stdev,Aerr,'ro',label="$A_{err}$")
pl.errorbar(stdev,Aerr,pl.std(Aerr),fmt='ro')
pl.loglog(stdev,Berr,'go',label="$B_{err}$")
pl.errorbar(stdev,Berr,pl.std(Berr),fmt='go')
pl.grid(True)
pl.xlabel("\u03C3",size=11)
pl.ylabel("$MSerror$")
pl.title("Q11. changes in Error with Noise(loglog scale)")
pl.legend()
pl.show()
